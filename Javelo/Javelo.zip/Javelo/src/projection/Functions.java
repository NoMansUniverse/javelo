package projection;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;

import java.util.function.DoubleUnaryOperator;

public final class Functions {

    public Functions(){};

    public static DoubleUnaryOperator constant(double y) {
        System.out.println(y);

        return new Constant(y);
    }

    private record Constant(double y) implements DoubleUnaryOperator {


        @Override
        public double applyAsDouble(double constant) {

            return constant;
        }
    }

    public static DoubleUnaryOperator sampled(float[] samples, double xMax) {
        return new Sampled(samples,xMax);
    }

    private record Sampled(float[] samples, double xMax) implements DoubleUnaryOperator {

        Sampled{
            Preconditions.checkArgument(samples.length >=2 || xMax>0);
        }



        @Override
        public double applyAsDouble(double x) {

            double intervalle = this.xMax()/this.samples().length;
            System.out.println(this.xMax());

            return 5.0;
        }
    }
}
package projection;

import ch.epfl.javelo.Math2;

public final class WebMercator {
    private WebMercator(){ }

    public static double x(double lon){

        double x = (lon+Math.PI)*(1.0/Math.PI*2);


        return x;
    }

    public static double y(double lat){

        double y = (Math.PI - Math2.asinh( Math.tan(lat) ) )
                *(1.0/Math.PI*2);


        return y;
    }

    public static double lon(double x){

        double lambda = Math.PI*(2*x-1);

        return  lambda;
    }

    public static double lat(double y){

        double phi = Math.atan( Math2.asinh(Math.PI - 2 *Math.PI*y) );

        return  phi;
    }

}

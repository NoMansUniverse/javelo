package projection;

import ch.epfl.javelo.Preconditions;

public record PointWebMercator(double x, double y) {

    private boolean checkInterval(double d, double y){

        if(x < 0 && x > 1 || y < 0 && y > 1){
            return true;

        }
        return false;
    }
    public PointWebMercator{
        Preconditions.checkArgument(checkInterval(x(),y()));

    }
    public static PointWebMercator of(int zoomLevel, double x , double y){
        double zoomSize = (double) Math.scalb(x,zoomLevel+8);

        double xDezoomed = x/zoomSize;
        double yDezoomed = y/zoomSize;



        PointWebMercator pointDezoomed = new PointWebMercator(xDezoomed,yDezoomed);


        return pointDezoomed;

    }

    public static  PointWebMercator ofPointCh(PointCh pointCh){

        PointWebMercator convertMercator = new PointWebMercator(pointCh.e(),pointCh.n());

        return convertMercator;
    }

    public  double xAtZoomLevel(int zoomLevel){
        double xZoom = Math.scalb(x(),zoomLevel+8);


        return xZoom;



    }
    public  double yAtZoomLevel(int zoomLevel){
        double yZoom = Math.scalb(y(),zoomLevel+8);


        return yZoom;


    }
    public double lon(){
       return
               WebMercator.lon(x());
    }
    public double lat(){
        return
                WebMercator.lat(y());
    }

    public PointCh toPointCh(){
        if(SwissBounds.containsEN(x(),y())){
            return null;
        }
        double e = Ch1903.e(lon(),lat());
        double n = Ch1903.n(lon(),lat());


        

        return new PointCh(e,n);
    }
}

package ch.epfl.javelo;

import projection.Functions;

public class Main {
    public static void main(String[] args) {
        float test[] = {1,2,3,4,5};
        Functions.constant(5);

    }
}
